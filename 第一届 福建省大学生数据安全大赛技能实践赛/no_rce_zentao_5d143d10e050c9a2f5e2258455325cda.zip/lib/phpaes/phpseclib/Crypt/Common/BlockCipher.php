<?php

/**
 * Base Class for all block ciphers
 *
 * PHP version 5
 *
 * @category  Crypt
 * @package   BlockCipher
 * @author    Jim Wigginton <terrafrost@php.net>
 * @author    Hans-Juergen Petrich <petrich@tronic-media.com>
 * @copyright 2007 Jim Wigginton
 * @license   http://www.opensource.org/licenses/mit-license.html  MIT License
 * @link      http://phpseclib.sourceforge.net
 */

//namespace phpseclib\Crypt\Common;
include PHPAES_ROOT . '/phpseclib/Crypt/Common/SymmetricKey.php';

/**
 * Base Class for all block cipher classes
 *
 * @package BlockCipher
 * @author  Jim Wigginton <terrafrost@php.net>
 */
abstract class BlockCipher extends SymmetricKey
{
}
