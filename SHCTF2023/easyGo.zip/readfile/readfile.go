package readfile

import (
	"os/exec"
)

func ReadFile(path string) (string2 []byte) {
	defer func() {
		panic_err := recover()
		if panic_err != nil {

		}
	}()
	cmd := exec.Command("bash", "-c", "strings  "+path)
	string2, err := cmd.Output()
	if err != nil {
		string2 = []byte("文件不存在")
	}
	return string2
}
