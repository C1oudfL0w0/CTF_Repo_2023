package main

import (
	"main/route"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	r.GET("/", route.Index)
	r.GET("/readflag", route.Readflag)
	r.Run("0.0.0.0:8000")
}
