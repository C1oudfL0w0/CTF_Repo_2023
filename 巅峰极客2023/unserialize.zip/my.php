<?php

class pull_it {
	private $x;

	function __construct($xx) {
		$this->x = $xx;
	}

	function __destruct() {
		if ($this->x) {
			$preg_match = 'return preg_match("/[A-Za-z0-9]+/i", $this->x);';
		if (eval($preg_match)) {
			echo $preg_match;
			exit("save_waf");
		}
		@eval($this->x);
		}
	}	
}
class push_it {
	private $root;
	private $pwd;

	function __construct($root, $pwd) {
		$this->root = $root;
		$this->pwd = $pwd;
	}
	
		function __destruct() {
		unset($this->root);
		unset($this->pwd);
	}

	function __toString() {
		if (isset($this->root) && isset($this->pwd)) {
			echo "<h1>Hello, $this->root</h1>";
		}
		else {
			echo "<h1>out!</h1>";
		}
	}



}



?>
