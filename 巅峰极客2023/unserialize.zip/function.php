<?php
function b($data) {
	return str_replace('aaaa', 'bbbbbb', $data);
}

function a($data) {
	return str_replace('bbbbbb', 'aaaa', $data);
}
?>