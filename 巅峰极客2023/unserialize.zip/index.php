<?php
include_once "my.php";
include_once "function.php";
include_once "login.html";
session_start();

if (isset($_POST['root']) && isset($_POST['pwd'])) {
	$root = $_POST['root'];
	$pwd = $_POST['pwd'];
	$login = new push_it($root, $pwd);
	$_SESSION['login'] = b(serialize($login));
	die('<script>location.href=`./login.php`;</script>');
}



?>
