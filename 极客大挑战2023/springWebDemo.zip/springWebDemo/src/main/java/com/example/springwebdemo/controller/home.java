package com.example.springwebdemo.controller;

import com.example.springwebdemo.redis;
import com.example.springwebdemo.input;
import com.example.springwebdemo.model.User;
import com.example.springwebdemo.output;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.Map;

@Controller
public class home {

    @RequestMapping(value = "/",method = RequestMethod.GET)
    public String index(HttpSession session) throws IOException {
        return "home";
    }
    @RequestMapping(value = "/error",method = RequestMethod.GET)
    public String error(){
        return "error";
    }
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public String login(HttpSession session, HttpServletRequest request, RedirectAttributes redirectAttributes) throws Exception {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        if (username.equals("admin") && password.equals("123456")){
            session.setAttribute("user", username);
            if (redis.get(session.getId()+"admin") == null){
                User u = new User();
                u.name ="admin";
                u.sex = "男";
                u.age = 10;
                redis.save(session.getId()+"admin",marshalinfo(u));
            }
            return "redirect:admin";
        }else {
            session.setAttribute("user", "");
            redirectAttributes.addAttribute("msg","登录失败");
            return "redirect:error";
        }
    }

    @RequestMapping(value = "/admin",method = RequestMethod.GET)
    public String admin(HttpSession session, RedirectAttributes redirectAttributes, Model model) throws Exception{
        Object user = session.getAttribute("user");
        if (user == null || user.toString().equals("")){
            redirectAttributes.addAttribute("msg","请先登录");
            return "redirect:error";
        }
        String name = user.toString();
        User userinfo = (User)new input(new ByteArrayInputStream(Base64.getDecoder().decode(redis.get(session.getId()+name)))).readObject();
        Path path = Paths.get(userinfo.secretFile);
        if (!path.startsWith("/tmp")){
            redirectAttributes.addAttribute("msg","secret must be under /tmp");
            return "redirect:error";
        }
        byte[] secret = Files.readAllBytes(path);
        model.addAttribute("user",userinfo);
        model.addAttribute("secret",new String(secret));
        return "admin";
    }
    @RequestMapping(value = "/marshalinfo",method = RequestMethod.POST)
    @ResponseBody
    public String marshalinfo(User u) throws Exception {
        u.secretFile ="/tmp/admin_secret";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        output o = new output(out);
        o.writeObject(u);
        return Base64.getEncoder().encodeToString(out.toByteArray());
    }
    @RequestMapping(value = "/invoke",method = RequestMethod.POST)
    @ResponseBody
    public String save(HttpSession session,@RequestBody Map<String, String> info) throws Exception {
        Object user = session.getAttribute("user");
        if (user != null && !user.equals("")){
            String action = info.get("action");
            switch (action){
                case "update":
                    try{
                        String data = info.get("data");
                        User newInfo = (User)new input(new ByteArrayInputStream(Base64.getDecoder().decode(data))).readObject();
                        User oldInfo = (User)new input(new ByteArrayInputStream(Base64.getDecoder().decode(redis.get(session.getId()+user.toString())))).readObject();
                        oldInfo.name = newInfo.name;
                        oldInfo.sex = newInfo.sex;
                        oldInfo.age = newInfo.age;
                        oldInfo.hash = newInfo.hash;
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        output o = new output(out);
                        o.writeObject(oldInfo);
                        redis.save(session.getId()+user.toString(),Base64.getEncoder().encodeToString(out.toByteArray()));
                        return "更新成功 name、sex、age成功";
                    }catch (Exception e){
                        return "更新失败: "+e;
                    }
                default:
                    return "受支持action: " +action;
            }
        }else {
            return "请先登录";
        }
    }
}
