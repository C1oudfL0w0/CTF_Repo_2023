package com.example.springwebdemo;

import org.thymeleaf.util.ArrayUtils;

import java.io.*;
import java.util.ArrayList;

public class input extends ObjectInputStream {
    static String[] whiteList = new String[]{"java.util.ArrayList","com.example.springwebdemo.model.SafeString","com.example.springwebdemo.model.User"};
    public input(InputStream in) throws IOException {
        super(in);
    }
    protected ObjectStreamClass readClassDescriptor()
            throws IOException, ClassNotFoundException
    {
        String info = super.readUTF();
        int deep = super.readInt();
        if (deep > 3){
            throw new ClassNotFoundException("not support serialization deep rather then 3");
        }
        ObjectStreamClass desc =  super.readClassDescriptor();
        if (!ArrayUtils.contains(whiteList,desc.getName())){
            throw new ClassNotFoundException("not support class: "+desc.getName());
        }
        return desc;
    }
    protected void readStreamHeader()
            throws IOException, StreamCorruptedException
    {
        super.readUTF();
    }
}
