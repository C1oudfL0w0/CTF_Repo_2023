package com.example.springwebdemo;

import java.util.HashMap;
import java.util.Map;

public class redis {
    static Map<String,String> data = new HashMap<>();

    public static void save(String name, String info){
        data.put(name,info);
    }
    public static String get(String name){
        return data.get(name);
    }
}
