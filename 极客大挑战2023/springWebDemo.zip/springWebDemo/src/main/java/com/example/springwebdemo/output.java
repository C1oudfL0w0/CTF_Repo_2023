package com.example.springwebdemo;

import java.io.*;

public class output extends ObjectOutputStream {
    int deep;
    protected void writeClassDescriptor(ObjectStreamClass desc)
            throws IOException
    {
        super.writeUTF("current deep "+deep);
        super.writeInt(deep);
        super.writeClassDescriptor(desc);
        deep ++;
    }
    public output(OutputStream out) throws IOException {
        super(out);
    }
    protected void writeStreamHeader() throws IOException {
        super.writeUTF("my serilizer");
    }
}
