package com.example.springwebdemo.model;

import org.springframework.util.StringUtils;

import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;

public class User implements Serializable {

    public static String separator = "O.o";
    public String hash = "";
    public String name = "张三";
    public String sex = "男";
    public int age;
    public String secretFile ="/tmp/admin_secret";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSecretFile() {
        return secretFile;
    }

    public void setSecretFile(String secretFile) {
        this.secretFile = secretFile;
    }

    private void readObject(java.io.ObjectInputStream s)
            throws Exception{
        String data = (String) s.readObject();
        Field[] fields = this.getClass().getFields();
        if (StringUtils.countOccurrencesOf(data, User.separator) != fields.length-2){
            throw new Exception(String.format("`%s` is the separator of the split method, the number of `%s` occurrences must be "+(fields.length-2),User.separator,User.separator));
        }
        String[] splits = data.split(User.separator);

        for (int i = 1; i < fields.length; i++) {
            if(fields[i].getType().getName().equals("int")){
                fields[i].set(this,Integer.parseInt(splits[i-1]));
            }else{
                fields[i].set(this,splits[i-1]);
            }
        }
        this.hash = (String) s.readObject();
        if (StringUtils.countOccurrencesOf(this.hash, User.separator) != 0){
            throw new Exception("hash cont content O.o");
        }
    }
    private void writeObject(ObjectOutputStream os)
            throws Exception{
        Field[] fields = this.getClass().getFields();
        ArrayList<String> datas = new ArrayList<>();
        for (int i = 1; i < fields.length; i++) {
            if(fields[i].getType().getName().equals("int")){
                datas.add(String.valueOf(fields[i].get(this)));
            }else{
                datas.add(fields[i].get(this).toString());
            }
        }
        os.writeObject(String.join(User.separator,datas));
        os.writeObject(String.join("-",datas));
    }
}
