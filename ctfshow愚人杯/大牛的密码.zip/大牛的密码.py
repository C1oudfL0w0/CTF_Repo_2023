from Crypto.Util.number import *
from flag import flag
from Crypto.Util.Padding import pad
from random import *
def s_box(a):
    box=[i for i in range(a)]
    shuffle(box)
    return box
BLOCK=16
flag=pad(flag,BLOCK)
S_BOX=s_box(len(flag))
m=[i for i in flag]
def swap(a,b):
    tmp = a
    a = b
    b = tmp
def encrypt1(m):
    enc=[m[i:i+BLOCK] for i in range(0,len(m),BLOCK)]
    for i in enc:
        for j in range(BLOCK):
            aa=j*7%BLOCK
            swap(i[j],i[aa])
def encrypt2(m):
    for i in range(16):
        m=[m[i] for i in S_BOX]
    return m
encrypt1(m)
c=encrypt2(m)
print(S_BOX)
print(c)
'''
[9, 31, 32, 38, 20, 1, 22, 4, 8, 2, 11, 21, 7, 18, 46, 23, 34, 3, 19, 12, 45, 30, 27, 37, 5, 47, 28, 36, 0, 43, 39, 10, 29, 14, 40, 24, 33, 16, 17, 6, 42, 15, 26, 41, 44, 25, 35, 13]
[99, 111, 102, 11, 107, 49, 11, 53, 121, 48, 114, 117, 11, 95, 112, 95, 109, 115, 11, 95, 101, 95, 119, 117, 79, 123, 111, 48, 110, 95, 121, 116, 121, 125, 116, 11, 119, 11, 97, 67, 11, 11, 11, 11, 11, 99, 110, 104]
'''










