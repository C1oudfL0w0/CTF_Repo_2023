var express = require('express');
var path = require('path');
const undefsafe = require('undefsafe');
const flag="*****************"
var serialize = require('node-serialize');
var app = express();

class Brief {
    constructor() {
        this.owner = "whoknows";
        this.num = 0;
        this.ctfer = {};
    }

    write_ctfer(name, nickname) {
        this.ctfer[(this.num++).toString()] = {
            "name": name,
            "nickname": nickname
        };
    }

    edit_ctfer(id, name, nikename) {
        undefsafe(this.ctfer, id + '.name', name);
        undefsafe(this.ctfer, id + '.nikename', nikename);
    }

    remove_ctfer(id) {
        delete this.ctfer[id];
    }
}

var introduction = new Brief();
introduction.write_ctfer("the first name", "the first nickname");


app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(express.json());
app.use(express.urlencoded({
    extended: false
}));
app.use(express.static(path.join(__dirname, 'public')));


app.get('/', function (req, res, next) {
    res.render('index', {
        title: 'Welcome to ctfer\'s brief introduction'
    });
});

app.route('/add')
    .get(function (req, res) {
        res.render('mess', {
            message: 'Please use post to pass parameters'
        });
    })
    .post(function (req, res) {
        let name = req.body.name;
        let nickname = req.body.nickname;
        if (name && nickname) {
            introduction.write_ctfer(name, nickname);
            res.send("添加成功");
        } else {
            res.send("添加失败");
        }
    })

app.route('/edit')
    .get(function (req, res) {
      res.send("开始修改");
    })
    .post(function (req, res) {
        let id = req.body.id;
        let name = req.body.name;
        let nickname = req.body.nickname;
        if (id && name && nickname) {
            introduction.edit_ctfer(id, name, nickname);
            res.send("修改成功");
        } else {
           res.send("修改失败");
        }
    })

app.route('/delete')
    .get(function (req, res) {
        
    })
    .post(function (req, res) {
        let id = req.body.id;
        if (id) {
            introduction.remove_ctfer(id);
            
        } else {
            
        }
    })

app.route('/getflag')
 .get(function (req, res) {
    let array1={IIS:123,a:234,b:345}
    let q = req.query.q;

    if(black1(q)){
        if(array1[q.toUpperCase()]==123){
            res.render('mess', {
            message: flag
        });

        }
    }
})

app.route('/excite')
    .get(function (req, res) {
        let commands = {
            "less1": "Error",
            "less2": "Correct"
        };

        for (let index in commands) {
            console.log(commands[index])
            if(black2(commands[index])){
                try{
                    serialize.unserialize(commands[index]);
                }catch (e){
                    continue;
                }

            }}
        res.send("ok");
        res.end();
    })


app.use(function (req, res, next) {
    res.status(404).send('Sorry cant find that!');
});


app.use(function (err, req, res, next) {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});


function black1(arr) {
    let blacklist = ["s", "S", "i","I"];
    for (let i = 0; i < arr.length; i++) {
        const element = arr[i];
        if (blacklist.includes(element)) {
            return false;
        }
    }
    return true;
}
function black2(arr) {
    let blacklist = ["flag", "bash", "process","WEB","*","?","require","child","exec","&"];
    for (let i = 0; i < arr.length; i++) {
        const element = arr[i];
        if (blacklist.includes(element)) {
            return false;
        }
    }
    return true;
}




const port = 80;
app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`))
