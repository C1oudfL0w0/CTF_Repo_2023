package com.example.demo;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileInputStream;
import java.io.IOException;

public class DownloadServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

        String currentPath = this.getServletContext().getRealPath("/assets/");
        Object fileNameParameter = req.getParameter("filename");
        if (fileNameParameter != null) {
            String fileName = (String) fileNameParameter;
            resp.setHeader("Content-Disposition","attachment;filename="+fileName);
            try (FileInputStream input = new FileInputStream(currentPath + fileName)) {
                byte[] buffer = new byte[4096];
                while (input.read(buffer) != -1) {
                    resp.getOutputStream().write(buffer);
                }
            }
        } else {
            resp.setContentType("text/html");
            resp.getWriter().write("<a href=\"/download?filename=avatar.jpg\">avatar.jpg</a>");
        }
    }
}
