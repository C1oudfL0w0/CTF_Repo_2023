from Crypto.Util.number import *

key = 'flag{**********}'

bits = 1024
msg = bytes_to_long(key.encode())

e = 65537
p = getPrime(bits)
q = getPrime(bits)
n = p * q

def encrypt1(msg, e, n):
    c = pow(msg, e, n)
    return c

seed = p ^ q
a = getPrime(bits)
b = getPrime(bits)
n1 = getPrime(bits)


def encrypt2(seed):
    enc = []
    for i in range(10):
        seed = (a * seed + b) % n1
        enc.append(seed)
    return enc


c = encrypt1(msg, e, n)
enc = encrypt2(seed)
print("n = ", n)
print("c = ", c)
print("n1 = ", n1)
print("enc = ", enc)


