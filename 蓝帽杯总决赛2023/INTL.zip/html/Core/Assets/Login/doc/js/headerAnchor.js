$(document).ready(function(){
  $(".menu-help").click(function(){
    window.location.href="/cha";
  });
})
