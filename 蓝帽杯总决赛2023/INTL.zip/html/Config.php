<?php
$GetCookie = [
    'alipay' => 'http://'.$_SERVER['HTTP_HOST'].'/Core/GetCookie/zfb_gck.php',
    'tenpay' => 'http://'.$_SERVER['HTTP_HOST'].'/Core/GetCookie/qq_gck.php',
];
?>