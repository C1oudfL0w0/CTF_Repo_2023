          <footer class="footer">
          <?=$conf['sitename']?> 2019-2021.
          <div><?=$conf['footer']?>.</div>
          </footer>
            </div>
        </div>
		<script src="/Core/Assets/Assets/js/jquery.min.js"></script>
        <script src="/Core/Assets/Assets/js/popper.min.js"></script>
        <script src="/Core/Assets/Assets/js/bootstrap.min.js"></script>
        <script src="/Core/Assets/Assets/js/jquery.slimscroll.js"></script>
        <script src="/Core/Assets/Assets/js/app.js"></script>
		<script src="/Core/Assets/Assets/js/layer.js"></script>