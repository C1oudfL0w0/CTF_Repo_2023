<?php

$FLAG = getenv("FLAG");
@file_get_contents("http://".$_GET['url']. "?flag=" . $FLAG);
# but it's not the real flag
# beacuse someone say this year is not 2023 !!! like the post?
# notice -> time
# How should you get to where the flag is, the middleware will not forward requests that are not 2023
?>

