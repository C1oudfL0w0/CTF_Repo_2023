<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['xmpp_host'] = 'yunjuxiaoqu.yunhuiju.com';
$config['xmpp_domain'] = 'yunjuxiaoqu.yunhuiju.com';
