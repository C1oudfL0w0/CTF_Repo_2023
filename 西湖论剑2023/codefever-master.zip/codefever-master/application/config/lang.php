<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['en_langs'] = array(
    'en',
    'en-gb',
    'en-us',
    'en-au',
    'en-ca',
    'en-nz',
    'en-ie',
    'en-za',
    'en-jm',
    'en-jm',
    'en-bz',
    'en-tt'
);

$config['cn_langs'] = array(
    'zh-cn',
    'zh-tw',
    'zh-hk',
    'zh-mo',
    'zh-sg'
);
