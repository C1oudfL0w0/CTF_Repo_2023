<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['xmpp_host'] = 'hengdacheng.yunjutech.com';
$config['xmpp_domain'] = 'hengdacheng.yunjutech.com';
