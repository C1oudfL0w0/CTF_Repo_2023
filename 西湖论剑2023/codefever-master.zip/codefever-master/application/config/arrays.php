
<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['sel_period'] = array(
    '1' => 'INTERVAL 1 HOUR',
    '2' => 'INTERVAL 1 DAY',
    '3' => 'INTERVAL 2 DAY',
    '4' => 'INTERVAL 7 DAY',
    '5' => 'INTERVAL 1 MONTH',
);
