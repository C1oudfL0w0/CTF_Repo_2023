<?php defined('BASEPATH') or exit('No direct script access allowed');

// disk | sae
$config['storage_type'] = 'disk';
