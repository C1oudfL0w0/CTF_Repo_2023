<?php
$config['base_url'] = '?';
$config['use_page_numbers'] = TRUE;
$config['page_query_string'] = TRUE;
$config['first_link'] = '首页';
$config['last_link'] = '末页';
$config['query_string_segment'] = 'page';
$config['num_links'] = 5;
