<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['crontab'] = [
    // ['crontab', 'backend|customize', 'command']
    ['* * * * *', 'backend', 'repository_webhook run'],
];
