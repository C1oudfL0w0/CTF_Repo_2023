<?php
    $lang['base_cn'] = '中文';
    $lang['base_en'] = 'English';
    $lang['base_message'] = 'Message';
    $lang['base_error_message'] = 'Error message';
    $lang['base_error_message_tips'] = 'Sorry, please try again to visit the site, or refresh retry';
    $lang['base_go_home'] = 'Home';
    $lang['base_go_prepage'] = 'Return to previous page';
    $lang['base_confirm'] = 'Confirm';
    $lang['base_directory'] = 'Directory';
