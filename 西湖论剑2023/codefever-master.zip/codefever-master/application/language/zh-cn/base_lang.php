<?php
$lang['base_cn'] = '中文';
$lang['base_en'] = 'English';
$lang['base_message'] = '消息';
$lang['base_error_message'] = '错误提示';
$lang['base_error_message_tips'] = '抱歉，请重新尝试访问网站，或者刷新重试';
$lang['base_go_home'] = '返回主页';
$lang['base_go_prepage'] = '返回上一页';
$lang['base_confirm'] = '确定';
$lang['base_directory'] = '目录';
