<div style="width:100%;height:644px;" class="flexRowCenter bg-color<?php echo $appId;?>">
    <img src="/static/images/activity<?php echo $appId; ?>.png" style="width: 100%;height:100%;" />
</div>