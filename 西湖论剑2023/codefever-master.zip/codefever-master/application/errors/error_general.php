<!DOCTYPE html>
<html lang="en">
<head>
<title>Error</title>
</head>
<body>
	<div id="container">
		<h1><?php echo $heading; ?></h1>
		<?php //echo $message; ?>
	</div>
</body>
</html>
