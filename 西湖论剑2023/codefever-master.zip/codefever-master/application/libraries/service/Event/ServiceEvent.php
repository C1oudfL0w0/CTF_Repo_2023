<?php
// this is a abstract of Event data object
namespace service\Event;

use service\Event\Event;

class ServiceEvent extends Event {
}
