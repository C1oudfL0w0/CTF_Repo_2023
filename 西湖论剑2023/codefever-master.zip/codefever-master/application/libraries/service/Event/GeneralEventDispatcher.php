<?php

namespace service\Event;

use service\Event\EventDispatcher;
use service\Event\Event;

class GeneralEventDispatcher extends EventDispatcher {

    protected $eventHandler = [
    
    ];
}
