<?php
namespace service\Constant;

class MergeRequestStatus {
    const NULL = 0;
    const OPEN = 1;
    const MERGED = 2;
    const CLOSED = 3;
}
