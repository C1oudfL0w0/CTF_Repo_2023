[从零开始安装](install_from_scratch.md)

[Docker 镜像安装](install_via_docker.md)

[更新 CodeFever](update.md)
