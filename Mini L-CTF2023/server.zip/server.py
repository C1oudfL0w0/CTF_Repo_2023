import ast
import base64

input_data = input(">>> ")

parser_tree = ast.parse(input_data, mode = 'eval')
assert not any(isinstance(node, ast.Call) for node in ast.walk(parser_tree))
del ast

eval_result = eval(compile(parser_tree, filename = '', mode = 'eval'))
decode_base64 = int.from_bytes(base64.b64decode(input_data), byteorder = 'little')
del base64

if eval_result == decode_base64:
	flag = open("flag").read().strip()
	print(flag)