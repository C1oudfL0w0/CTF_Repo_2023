Do you know how to fuzz? What if you have no access to the source code?

Try using fuzzing to guess the flag! I will give you the code coverage!
