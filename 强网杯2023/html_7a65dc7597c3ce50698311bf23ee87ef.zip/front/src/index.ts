import { createEditor } from "./editor";

function save(code: string) {
  const hash = window.btoa(code);
  location.hash = hash;
}

function load() {
  return (
    window.atob(location.hash.slice(1)) || `<main id="main">\n    \n</main>`
  );
}

async function main() {
  const container = document.getElementById("editor");
  if (!container) return;
  const code = load();
  save(code);

  const { onChange } = await createEditor(container, code);

  onChange((code) => {
    save(code);
  });
}

window.addEventListener("DOMContentLoaded", main);