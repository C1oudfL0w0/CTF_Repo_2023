(() => {
    const htmlRef = /html:([^(]*).*\(\)/;

    const global = {};

    const isBlacklisted = Array.prototype.includes.bind(["__proto__", "prototype", "constructor"]);

    const commands = {
        // ===============================
        // Literals
        // ===============================
        // Maybe it's too dangerous, begin by making calculations
        // "s": function (elt, env) {  // push string onto stack
        //     env.stack.push(elt.innerText);
        // },
        "data": function (elt, env) {  // push number onto stack
            env.stack.push(Number.parseFloat(elt.innerText));
        },
        "ol": function (elt, env) {  // create list
            let children = elt.children;
            let initialLength = env.stack.length;
            let result = [];
            for (const child of children) {
                exec(child.firstElementChild, child, env);
                result.push(env.stack.pop());
                env.stack.length = initialLength;
            }
            env.stack.push(result);
        },
        // ===============================
        // Math Commands
        // ===============================
        "dd": function (elt, env) {  // add two numbers on top of stack
            let top = env.stack.pop();
            let next = env.stack.pop();
            if (typeof top !== "number" || typeof next !== "number") {
                console.error("Cannot add ", top, " and ", next);
                return null;
            }
            env.stack.push(next + top);
        },
        "sub": function (elt, env) {  // sub two numbers on top of stack
            let top = env.stack.pop();
            let next = env.stack.pop();
            if (typeof top !== "number" || typeof next !== "number") {
                console.error("Cannot subtract ", top, " and ", next);
                return null;
            }
            env.stack.push(next - top);
        },
        "ul": function (elt, env) {  // multiply two numbers on top of stack
            let top = env.stack.pop();
            let next = env.stack.pop();
            if (typeof top !== "number" || typeof next !== "number") {
                console.error("Cannot multiply ", top, " and ", next);
                return null;
            }
            env.stack.push(next * top);
        },
        "div": function (elt, env) {  // divide two numbers on top of stack
            let top = env.stack.pop();
            let next = env.stack.pop();
            if (typeof top !== "number" || typeof next !== "number") {
                console.error("Cannot divide ", top, " and ", next);
                return null;
            }
            env.stack.push(next / top);
        },
        // ===============================
        // Stack Manipulation Commands
        // ===============================
        "dt": function (elt, env) {  // duplicate top of stack
            env.stack.push(env.stack.at(-1));
        },
        "del": function (elt, env) {  // deletes the top of stack
            env.stack.pop();
        },
        // ===============================
        // Comparison Commands
        // ===============================
        "big": function (elt, env) { // next > top
            let top = env.stack.pop();
            let next = env.stack.pop();
            env.stack.push(next > top);
        },
        "small": function (elt, env) { // next < top
            let top = env.stack.pop();
            let next = env.stack.pop();
            env.stack.push(next < top);
        },
        "em": function (elt, env) { // equal, mostly
            let top = env.stack.pop();
            let next = env.stack.pop();
            env.stack.push(next == top);
        },
        // ===============================
        // Logical Operators
        // ===============================
        "b": function (elt, env) { // logical and
            let top = env.stack.pop();
            let next = env.stack.pop();
            env.stack.push(top && next);
        },
        "bdi": function (elt, env) { // logical not (invert)
            let top = env.stack.pop();
            env.stack.push(!top);
        },
        "bdo": function (elt, env) { // logical or
            let top = env.stack.pop();
            let next = env.stack.pop();
            env.stack.push(next || top);
        },
        // ===============================
        // Control Flow
        // ===============================
        "i": function (elt, env) {      // conditionally execute child instructions if true is on the top of the stack
            let topOfStack = env.stack.pop();
            if (topOfStack) {
                return elt.firstElementChild;
            }
        },
        "rt": function() { // return by returning null
            return null;
        },
        "a": function (elt, env) {          // either jump or invoke a function
            let href = elt.getAttribute("href");
            let regexMatch = htmlRef.exec(href);
            if (regexMatch) {

                let functionName = regexMatch.at(1);

                // collect args
                let args = [];
                if (elt.firstElementChild) {
                    let initialLength = env.stack.length;
                    exec(elt.firstElementChild, elt, env);
                    let finalLength = env.stack.length;
                    args = env.stack.slice(initialLength, finalLength);
                    env.stack.length = initialLength;
                }

                if (!functionName in env.scope.functions) {
                    console.error("Cannot invoke ", functionName);
                    return null;
                }
                let result = null;
                result = env.scope.functions[functionName](...args);

                if (typeof result != "undefined") {
                    env.stack.push(result);
                }
            } else {
                return document.getElementById(href.substring(1));
            }
        },
        // ===============================
        // Variables
        // ===============================
        "var": function (elt, env) {
            let topOfStack = env.stack.pop();
            let variableName = elt.innerText;
            if (isBlacklisted(variableName)) {
                console.error("Cannot store ", variableName);
                return null;
            }
            env.scope[variableName] = topOfStack;
        },
        "label": function (elt, env) { // stores a variable in the global scope
            let topOfStack = env.stack.pop();
            let variableName = elt.innerText;
            if (isBlacklisted(variableName)) {
                console.error("Cannot store ", variableName);
                return null;
            }
            global[variableName] = topOfStack;
        },
        "cite": function (elt, env) { // loads a variable
            let variableName = elt.innerText;
            if (isBlacklisted(variableName)) {
                console.error("Cannot load ", variableName);
                return null;
            }
            env.stack.push(env.scope[variableName] || global[variableName]);
        },
        // ===============================
        // I/O
        // ===============================
        "input": function (elt, env) {  // get input from user
            let value = prompt(elt.getAttribute('placeholder'));
            env.stack.push(value = Number.parseFloat(value));
        },
        "output": function (elt, env) { // outputs to standard out
            let top = env.stack.at(-1);
            env.scope.functions.out(top);
        },
        "dl": function (elt, env) { // debug output
            env.scope.functions.out(elt.innerText, "stack:", env.stack, "vars:", env.scope)
        },
        // ===============================
        // Arrays
        // ===============================
        "address" : function (elt, env) { // read an offset into an array on the top element on the stack
            let index = env.stack.pop();
            let array = env.stack.pop();
            if (!Array.isArray(array) || !array.hasOwnProperty(index) || isBlacklisted(index)) {
                console.error(`Cannot read ${index} from ${array}`);
                return null;
            }
            env.stack.push(array[index]);
        },
        "ins" : function (elt, env) { // insert the top of the stack into the array third from the top at index second
            let val = env.stack.pop();
            let array = env.stack.pop();
            array.push(val);
        },
        "fieldset" : function (elt, env) { // set a value in an array to the top of the stack
            let val = env.stack.pop();
            let index = env.stack.pop();
            let array = env.stack.pop();
            if (isBlacklisted(index)) {
                console.error("Cannot set ", index);
                return null;
            }
            array[index] = val;
        },
        // ===============================
        // Functions
        // ===============================
        "dfn": function (elt, env) {},
        // ===============================
        // Programs
        // ===============================
        "main": function (elt, env) {
            return elt.firstElementChild;
        },
        "body": function (elt, env) {
            return elt.firstElementChild;
        },
    };

    function nextEltToExec(elt) {
        if (elt == null || elt.matches("body, main")) {
            return null;
        } else if (elt.nextElementSibling) {
            return elt.nextElementSibling;
        } else {
            return nextEltToExec(elt.parentElement);
        }
    }

    function defineFunctions(sourceOrElt, env) {
        let definitions = sourceOrElt.querySelectorAll(':scope > dfn');
        for (const definition of definitions) {
            if (definition.parentElement.tagName !== "MAIN") {
                console.error("Function defined at ", definition, " does not have a parent MAIN element, instead found ", definition.parentElement);
                continue;
            }
            const funcName = definition.id;
            env.scope.functions[funcName] = function () {
                var args = Array.from(arguments);
                let env = makeEnv();
                env.stack.push(...args);
                if (definition.firstElementChild) {
                    exec(definition.firstElementChild, definition, env);
                }
                let val = env.stack.pop();
                return val;
            };
        }
    }

    function makeEnv() {
        const env = {
            stack: [],
            scope: { // start with standard variables for common values
                true:true,
                false:false,
                null:null,
                functions: {
                    out: (...args) => alert(...args),
                },
            },
        };
        return env;
    }

    function exec(sourceOrElt, root, env) {
        if (sourceOrElt == null) {
            console.error("No html source detected")
            return;
        }
        // set the root element if necessary
        root ||= sourceOrElt;
        // create an environment if necessary
        env ||= makeEnv();
        // set the current element to execute
        let eltToExec = sourceOrElt;
        // define all functions within the element
        defineFunctions(eltToExec, env);
        do {
            // resolve command for the current element
            const tagName = eltToExec.tagName.toLowerCase();
            if (!commands.hasOwnProperty(tagName)) {
                console.error(`Could not find command definition for "${tagName}"`);
                break;
            }
            let commandForElt = commands[tagName];
            // invoke command and get next element
            var next = commandForElt(eltToExec, env);
            if (next === undefined) {
                eltToExec = nextEltToExec(eltToExec);
            } else {
                eltToExec = next;
            }
            // if the next element is outside the root, we are done
            if (!root.contains(eltToExec)){
                return;
            }
        } while (eltToExec)
    }

    document.querySelector("#run").addEventListener("click", function () {
        exec(new DOMParser().parseFromString(atob(location.hash.slice(1)), "text/html").querySelector('main'));
    });

    document.querySelector("#report").addEventListener("click", function () {
        fetch('/api/report', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                program: location.hash.slice(1),
            }),
        }).then(res => res.json()).then(res => {
            if (!res.success) {
                alert("Excution failed");
            } else {
                alert(res.result);
            }
        });
    });
})();