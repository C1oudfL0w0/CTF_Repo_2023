/**
 *  This is not part of the challenge, but feel free to use a monaco 0day :D
 */

export async function createEditor(container: HTMLElement, code: string = "") {
  const monaco = await import("monaco-editor");

  type OnChangeCallback = (code: string) => void;

  const onChangeCallbacks: OnChangeCallback[] = [];

  const editor = monaco.editor.create(container, {
    language: "html",
    theme: "vs-dark",
    automaticLayout: true,
    value: code,
  });

  const model = editor.getModel();
  if (!model) {
    throw new Error("Could not get model");
  }

  model.onDidChangeContent(() => {
    const code = editor.getValue();
    onChangeCallbacks.forEach((cb) => cb(code));
  });

  return {
    onChange(cb: OnChangeCallback) {
      onChangeCallbacks.push(cb);
    },
  };
}
