import puppeteer, { Browser, Dialog, Page } from "puppeteer";
import express from "express";

const FLAG = process.env.FLAG || "flag{FAKE_FLAG}";

const app = express();

app.use(express.static("public"));
app.use(express.json());
let browser: Browser;

async function initBrowser() {
  browser = await puppeteer.launch({
    headless: true,
    args: ["--disable-gpu", "--no-sandbox"],
    executablePath: "/usr/bin/chromium-browser",
  });
}
async function testProgram(page: Page, base64Program: string) {
  const msgs: string[] = [];
  page.setCookie({
    name: "FLAG",
    value: FLAG,
    domain: "127.0.0.1",
  });
  await page.goto(`http://127.0.0.1:3000/#${base64Program}`, {
    waitUntil: "load",
  });

  page.on("dialog", (dialog: Dialog) => {
    msgs.push(dialog.message());

    dialog.dismiss().catch(() => {});
  });

  page
    .evaluate(() => {
      document.querySelector<HTMLElement>("#run")!.click();
    })
    .catch(() => {});
  await page.waitForTimeout(10000);
  const output = msgs.join("\n");
  if (output) return `Nice program! Here is the output:\n\n${output}`;
  else return "WTF is going on? no output";
}

app.post("/api/report", async (req, res) => {
  const program = `${req.body.program}`;

  const ctx = await browser.createIncognitoBrowserContext();
  const page = await ctx.newPage();
  try {
    const result = await testProgram(page, program);
    return res.send({ success: true, result });
  } catch (e) {
    console.error(e);
    return res.send({ success: false });
  } finally {
    page.close();
  }
});

app.listen(3000, async () => {
  await initBrowser();
  console.log("Bot ready, listening on port 3000");
});
