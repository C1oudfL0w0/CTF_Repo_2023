import os 
import subprocess 
from flask import Flask ,render_template ,request 

jar_path = [已隐藏，内容不重要]
'''老板要我出一个攻击者绝对不会发现的CTF题目
我使用java开发真正需要处理的核心逻辑，并且隐藏在后端，这样绝对安全了
因为攻击者只可能去傻傻的寻找python漏洞，其实不知道应该去寻找Java的经典漏洞
而且我有日志记录攻击者轨迹随时可以发现
他们做梦也想不到我把flag藏在了FLAG环境变量里:-)
'''

app =Flask (__name__ )

@app .route ("/",methods =['GET','POST'])
def aaa():
    if request .method =='POST':
        OOO0000O0000O00O0 =request .form ['text'].split (' ')
        O00O0OO0OO00000OO =''
        if len (OOO0000O0000O00O0 )<1 :
            return ('oh, invalid message',400 )
        elif len (OOO0000O0000O00O0 )<2 :
            O00O0OO0OO00000OO =OOO0000O0000O00O0 [0 ]
            OOO0000O0000O00O0 =''
        else :
            O00O0OO0OO00000OO ,OOO0000O0000O00O0 =OOO0000O0000O00O0 [0 ],' '.join (OOO0000O0000O00O0 [1 :])
        OOO0OOO0000OO0000 =bbb (O00O0OO0OO00000OO ,OOO0000O0000O00O0 )
        return OOO0OOO0000OO0000 
    return render_template ('home.html')

def bbb (O0OOOO0O0000OOOOO ,O000O0O0O00O00OO0 ):
    with open("/flag","r") as f:
        FLAG = f.read()
    O00000O0OOO0OO00O =subprocess .run (['java','-jar','-Dcmd='+O0OOOO0O0000OOOOO ,jar_path,'--',O000O0O0O00O00OO0 ],
                                        capture_output =True ,timeout =12,env={"FLAG":FLAG})
    return O00000O0OOO0OO00O .stdout .decode ('utf-8')

if __name__ =='__main__':
    port =os .environ ['PORT']if 'port'in os .environ else 1337 
    app .run (host ='0.0.0.0',port =port )
