#!/bin/bash
service mysql start && sudo --preserve-env=dbhost --preserve-env=dbname --preserve-env=dbpasswd --preserve-env=dbuser -u ctf pm2-docker process.yaml