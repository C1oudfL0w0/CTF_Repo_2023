(function () {
    var registerElem = document.getElementById('register-form');
    if (registerElem) {
        var submitBtn = registerElem.children[3];
        submitBtn.addEventListener("click", function (e) {
            var password1 = registerElem.children[1];
            var password2 = registerElem.children[2];
            if (password1.value === password2.value) {
                password2.setAttribute("disabled", "true");
                registerElem.submit();
            } else {
                e.preventDefault()
                document.getElementById("message").innerText = "Passwords do not match";
            }
        })
    }

}());