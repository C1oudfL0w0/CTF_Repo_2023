const pool = require('../libs/pool')
const handlebars = require('handlebars')

const blogController = {
    homePage: (req, res) => {
        if (req.session.user) {
            return res.render('user', { layout: 'member', username: req.session.user.username });
        }
        return res.render('index');
    },
    getPosts: async (req, res, next) => {
        let conn = null;
        const userId = req.session.user.id;
        try {
            conn = pool.promise();
            const [postRows] = await conn.query('SELECT id, title, content FROM posts WHERE userid = ?', [userId]);
            return res.render('posts', { layout: 'member', posts: postRows });
        } catch (err) {
            next(err);
        }
    },
    getPost: async (req, res, next) => {
        let conn = null;
        const postId = req.params.id;
        const userId = req.session.user.id;
        const style = req.session.user.style;
        try {
            conn = pool.promise();
            const [postRows] = await conn.query('SELECT title, content FROM posts WHERE id = ? and userid = ?', [postId, userId]);
            if (postRows.length === 0) {
                return res.render('post-details', { layout: 'member', post: { title: 'No such post.' } });
            }
            return res.render('post-details', { layout: 'member', post: postRows[0], style: handlebars.compile(style ?? '')() });
        } catch (err) {
            next(err);
        }
    },
    newPostPage: (req, res) => {
        return res.render('newpost', { layout: 'member' });
    },
    newPost: async (req, res, next) => {
        const userId = req.session.user.id;
        const title = req.data.title;
        const content = req.data.content;
        let conn = null;
        try {
            conn = await pool.promise();
            await conn.query("INSERT INTO posts VALUES (0, ?, ?, ?)", [userId, title, content]);
            return res.redirect('/posts');
        } catch (error) {
            next(error);
        }
    },
    stylePage: async (req, res, next) => {
        let conn = null;
        const userId = req.session.user.id;
        try {
            conn = pool.promise();
            const [styleRows] = await conn.query('SELECT style FROM users WHERE id = ?', [userId]);
            return res.render('style', { layout: 'member', style: styleRows[0].style });
        } catch (err) {
            next(err);
        }
    },
    style: async (req, res, next) => {
        let conn = null;
        const userId = req.session.user.id;
        const style = req.data.style;
        try {
            conn = pool.promise();
            await conn.query('UPDATE users SET style = ? WHERE id = ?', [style, userId]);
            req.session.user.style = style;
            return res.render('style', { layout: 'member', style: style ?? '' });
        } catch (err) {
            next(err);
        }
    },
    clearPosts: async (req, res, next) => {
        const userId = req.session.user.id;
        let conn = null;
        try {
            conn = await pool.promise();
            await conn.query("DELETE FROM posts WHERE userid = ?",
                [userId]);
            return res.render('posts', { layout: 'member' });
        } catch (error) {
            next(error);
        }
    }
}

module.exports = blogController;