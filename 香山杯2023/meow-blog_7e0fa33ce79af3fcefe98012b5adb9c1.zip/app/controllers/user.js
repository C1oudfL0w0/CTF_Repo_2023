const { v4: uuid } = require('uuid');
const pool = require('../libs/pool')

const userController = {
    loginPage: (req, res) => {
        if (req.session.user) {
            return res.redirect('/');
        }
        return res.render('login');
    },
    registerPage: (req, res) => {
        if (req.session.user) {
            return res.redirect('/');
        }
        return res.render('register');
    },
    login: async (req, res, next) => {
        let conn = null;
        try {
            if (req.session.user) {
                return res.redirect('/');
            }
            const username = req.data.username;
            const password = req.data.password;
            if (!username || !password) {
                return res.status(401).render('login', { message: 'Field can\'t be empty.' });
            }
            conn = pool.promise();
            const [formerUserRows] = await conn.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password])
            if (formerUserRows.length === 0) {
                return res.status(401).render('login', { message: 'Username or password error.' });
            }
            req.session.user = {
                username: username,
                id: formerUserRows[0].id,
                style: formerUserRows[0].style
            }
            return res.redirect('/');
        } catch (err) {
            next(err);
        }
    },
    register: async (req, res, next) => {
        let conn = null;
        try {
            if (req.session.user) {
                return res.redirect('/');
            }
            const username = req.data.username;
            const password = req.data.password;
            if (!username || !password) {
                return res.status(401).render('register', { message: 'Field can\'t be empty.' });
            }
            conn = pool.promise();
            const [formerUserRows] = await conn.query('SELECT * FROM users WHERE username = ?', [username])
            if (formerUserRows.length !== 0) {
                return res.status(401).render('register', { message: 'Username has already been taken.' });
            }

            const userId = uuid();
            await conn.query('INSERT INTO users VALUES (?, ?, ?, ?)', [userId, username, password, 0])
            req.session.user = {
                username: username,
                id: userId
            }
            return res.redirect('/');
        } catch (err) {
            next(err);
        }
    },
    logout: (req, res) => {
        req.session.user = undefined;
        return res.redirect('/');
    }
}

module.exports = userController;