const express = require('express');
const handlebars = require('handlebars');
const expressHbs = require('express-handlebars');
const parser = require('body-parser');
const session = require('express-session')
const fileStore = require('session-file-store')(session);
const crypto = require('crypto')
const wrapper = require('./libs/wapper')
const userController = require('./controllers/user');
const blogController = require('./controllers/blog');
const middlewares = require('./libs/middleware');

const app = express();

handlebars.registerHelper("preview", wrapper);

app.engine('.hbs', expressHbs.engine({
  handlebars: handlebars,
  defaultLayout: 'anonymous',
  extname: '.hbs'
}));
app.set('view engine', '.hbs');
app.set('views', './templates');
app.use(express.static('assets'));
app.use(session({
  name: "session",
  secret: crypto.randomBytes(16).toString('base64'),
  store: new fileStore({}),
  resave: false,
  saveUninitialized: false
}));
app.use(parser.urlencoded({ extended: true }));
app.use(parser.json());
app.use(middlewares.banProto);
app.use(middlewares.waf);

app.get('/', blogController.homePage);
app.get('/posts', middlewares.auth, blogController.getPosts);
app.get('/posts/:id', middlewares.auth, blogController.getPost);
app.get('/newpost', middlewares.auth, blogController.newPostPage);
app.get('/style', middlewares.auth, middlewares.role, blogController.stylePage);

app.get('/register', userController.registerPage);
app.get('/login', userController.loginPage);
app.get('/logout', userController.logout);

app.post('/register', userController.register);
app.all('/login', userController.login);

app.post('/posts', middlewares.auth, blogController.newPost);
app.post('/clearposts', middlewares.auth, blogController.clearPosts);
app.post('/style', middlewares.auth, middlewares.role, blogController.style);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render('error', { error: err.toString() });
});

app.listen(5000, () => console.log(`App listening to port 5000`));