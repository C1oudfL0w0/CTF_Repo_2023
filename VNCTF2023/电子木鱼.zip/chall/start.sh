#!/bin/sh
/app/cyberwoodenfish
